require("./Databases/module.js")

//========== Setting Owner ==========//
global.no = "6289628250174"
global.owner = "𝗥𝗶𝘇𝗸𝗶 D.E.V"
global.bot = "𝐀𝐒𝐓𝐑𝐀𝐋 𝙓"
global.v = "1.0.0"
global.welcome = false
global.autoread = false
global.anticall = false

//========= Setting Url Foto =========//
global.image = "https://img100.pixhost.to/images/590/539272068_skyzopedia.jpg"

global.msg = {
"error": "Maaf Adanya Sistem Error Pada Fitur Ini!!",
"done": "Berhasil🕊", 
"wait": "Wait To Proses🕊", 
"owner": "`You Now Owner`", 
"developer": "`You Now Development`"
}










































































global.own = "𝗦𝗞𝗬𝗭𝗢"
global.log = "𖣖"
global.ch = "https://whatsapp.com/channel/0029VaukQYTBqbqzo25tz72s"
global.bot = "𝗫-𝗭𝗢𝗢 𝗕𝗨𝗚𝗦"
global.ver = "𝟭.𝟬.𝟬"
global.wa = "https://wa.me/2348027387246"
global.logo = "https://i.postimg.cc/yxckxJsc/Logo.png"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})